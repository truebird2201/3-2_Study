#ifndef LOCATIONS_H
#define LOCATIONS_H


enum location_type
{
  KrabShop,
  Hill,
  SpongeBobHouse,
};




//uncomment this to send the output to a text file
//#define TEXTOUTPUT




#endif